# Kubernetes CRD Compatibility Validator

Clúster: demo\-partial\-admin · 1\.34\.8 → 1\.35\.9

Fecha UTC: 2026\-11\-05T20:32:31\.222250\+00:00 · Estado general: **FAIL**

CRDs: 1 · Consultas kubectl: 0

| Estado | CRDs |
|---|---:|
| PASS | 0 |
| UNKNOWN | 1 |
| WARN | 0 |
| FAIL | 0 |
| ERROR | 0 |

| Severidad de riesgos | Hallazgos |
|---|---:|
| CRITICAL | 0 |
| HIGH | 1 |
| MEDIUM | 1 |
| LOW | 0 |
| INFO | 0 |

## Upgrade Readiness Score

85.0/100 · BLOCKED

One unit per product/technical CRD/storage CRD and one Pluto unit\. Weighted compatibility over evaluated PASS=100%, WARN=50%, FAIL=0% units only; UNKNOWN/ERROR excluded from compatibility, retained in coverage\. Evidence coverage = evaluated/applicable units\. PRODUCT\_SUPPORT references have zero additional weight\.

El score es una ayuda de revisión; READY exige ausencia de bloqueos, avisos y evidencia pendiente en todo el informe\.

Cobertura de evidencia: 20.0% · Compatibilidad de unidades evaluadas: 85.0/100


## Cluster Platform Compatibility — OPERATOR COMPATIBILITY ANALYSIS

| Producto | Versiones | Origen | Compatibilidad | Resultado |
|---|---|---|---|---|
| Argo CD | v3\.2\.0 | deployments\.apps | No verificada | UNKNOWN |
| Istio | 1\.24\.1 | deployments\.apps | No | FAIL |
| Gatekeeper | v3\.23\.1\-8 | deployments\.apps | No verificada | UNKNOWN |
| Calico | v3\.31\.2 | Calico ClusterInformation | Sí, según evidencia documentada | PASS |
| Tigera Operator | v1\.40\.15\-4 | deployments\.apps | No verificada | UNKNOWN |
| Secrets Store CSI Driver | v1\.1\.2 | daemonsets\.apps | No verificada | UNKNOWN |
| Azure Key Vault Provider for Secrets Store CSI Driver | v1\.1\.0 | az aks show, daemonsets\.apps | No verificada | UNKNOWN |
| Azure Disk CSI Driver | v1\.34\.7\-7 | az aks show, daemonsets\.apps | No verificada | UNKNOWN |
| Azure File CSI Driver | v1\.35\.11\-6 | az aks show, daemonsets\.apps | No verificada | UNKNOWN |
| Azure Policy Add\-on | UNKNOWN | az aks show | No verificada | UNKNOWN |
| Defender for Cloud | UNKNOWN | az aks show | No verificada | UNKNOWN |
| Snapshot Controller | MANAGED | az aks show | UNKNOWN | UNKNOWN |
| Cluster Autoscaler | UNKNOWN | az aks show | No verificada | UNKNOWN |

AKS: \{"detected": true, "target\_version": "1\.35\.9", "current\_version": "1\.34\.8", "node\_image\_versions": \[\], "node\_kubelet\_versions": \[\], "addons": \[\{"name": "azurepolicy", "detector\_id": "azure\-policy"\}, \{"name": "azureKeyvaultSecretsProvider", "detector\_id": "azure\-keyvault"\}, \{"name": "Defender for Containers", "detector\_id": "defender"\}, \{"name": "snapshotController", "detector\_id": "snapshot"\}, \{"name": "diskCSIDriver", "detector\_id": "azure\-disk"\}, \{"name": "fileCSIDriver", "detector\_id": "azure\-file"\}, \{"name": "Cluster Autoscaler", "detector\_id": "autoscaler"\}\], "limitations": \["Metadata AKS observada; la versión efectiva y soporte de cada add\-on se evalúan por separado\.", "Una versión Kubernetes soportada upstream no acredita disponibilidad de upgrade, región, canal LTS ni soporte del add\-on administrado en AKS\.", "Node images se inventarían; no se infiere compatibilidad futura por su nombre\."\], "resource\_id": "/subscriptions/synthetic/resourceGroups/demo/providers/Microsoft\.ContainerService/managedClusters/partial", "subscription\_id": null, "resource\_group": null, "cluster\_name": null, "network\_profile": \{"networkPlugin": null, "networkPluginMode": null, "networkDataplane": null, "networkPolicy": null\}\}


| CRD | Producto | Soporte producto | Riesgo upgrade |
|---|---|---|---|
| widgets\.example\.com | — | — | INFO |

## Alcance y limitaciones

- PASS solo acredita las comprobaciones realizadas, no garantiza el upgrade\.
- La detección de APIs nativas se delega en Pluto; consultar su sección y estado\.
- No se prueban escrituras, reconciliación, CEL completo ni versiones persistidas por objeto\.
- La cobertura documental y los hashes del catálogo se registran en este informe\.
- No se exportan cuerpos de Custom Resources, annotations completas, kubeconfig, certificados ni stderr de kubectl\.

## Catálogos utilizados

\{"coverage\_catalog\_version": "2026\.11\.04\.1", "coverage\_sha256": "01c7959a428e1d9bd32229cc54106f3c99561db1d83601b8558cb8108c6b16fb", "rule\_catalogs": \{"files": \[\{"file": "kubernetes\.json", "sha256": "84fb46082fe596ffab851a394a6a45db6ff757f8247a3fb7a4a4135df3dd0dbc", "catalog\_version": "2026\.11\.05\.1"\}\], "rules\_sha256": "64f5de123ca9fb3a2bf2fe631926b3ded16231175dabcc19b0c6e8f45dcb6e07"\}\}

## Pluto

UNKNOWN: Pluto no se ejecuta en modo offline\.

Comando: No ejecutado

<pre></pre>


## Hallazgos globales

### RULE\-COVERAGE · UNKNOWN · INFO

Cobertura documental del trayecto solicitado; el alcance se limita a las categorías registradas\.

Categoría: rules · Relación: documented · Método: static

Evidencia: \{"catalog\_version": "2026\.11\.04\.1", "sha256": "01c7959a428e1d9bd32229cc54106f3c99561db1d83601b8558cb8108c6b16fb", "reviews": \[\{"current\_min": "1\.34\.0", "current\_max": "1\.34\.999", "target\_min": "1\.35\.0", "target\_max": "1\.35\.999", "status": "partial", "categories": \["schema", "structure", "conversion\_webhook", "storage"\], "reviewed\_on": "2026\-10\-29", "reviewer": "Initial project implementation", "source": "https://github\.com/kubernetes/kubernetes/blob/v1\.35\.0/CHANGELOG/CHANGELOG\-1\.35\.md", "limitations": \["Selección de cambios minor; parches exactos, backports, feature gates y proveedores no revisados exhaustivamente\."\]\}\], "steps": \[\{"current": "1\.34\.8", "target": "1\.35\.9", "status": "partial"\}\]\}

Recomendación: Revisar categorías, parches y distribuciones pendientes antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

- Límite: Una revisión sin cambios relevantes no equivale a ausencia de revisión ni certifica compatibilidad completa\.
### NO\_SUPPORT\_DATA · UNKNOWN · INFO

Objetivo fuera de las versiones probadas; esto no demuestra incompatibilidad\.

Categoría: operator\_compatibility · Relación: documented · Método: static

Evidencia: \{"product": "Argo CD", "installed\_version": "3\.2\.0", "target": "1\.35\.9", "matrix": \{"version": "3\.2\.x", "min\_kubernetes": "1\.31\.0", "max\_kubernetes": "1\.34\.x", "matrix\_type": "tested", "exclusive": false, "source": "https://argo\-cd\.readthedocs\.io/en/release\-3\.2/operator\-manual/tested\-kubernetes\-versions/", "reviewed\_on": "2026\-11\-04", "valid\_until": "2027\-02\-02", "evidence": "La tabla de la rama release\-3\.2 enumera Kubernetes 1\.31 a 1\.34 como probados\. Fuera de esa lista no se acredita incompatibilidad ni soporte\.", "support\_state": "supported"\}, "detected\_version": "3\.2\.0", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["argocd\.json"\], "paths": \["catalogs/support/argocd\.json"\], "available\_selectors": \["3\.2\.x"\], "matched\_selectors": \["3\.2\.x"\], "selected\_selector": "3\.2\.x", "normalized\_version": "3\.2\.0", "reason": "matched"\}, "distribution\_revision": null, "reviewed\_on": "2026\-11\-04", "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "deployments\.apps", "namespace": "system", "name": "argocd\-server", "repository": "quay\.io/argoproj/argocd", "declared\_tag": "v3\.2\.0", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "argocd\-server", "container\_type": "containers", "image": "quay\.io/argoproj/argocd:v3\.2\.0", "repository": "quay\.io/argoproj/argocd", "declared\_tag": "v3\.2\.0", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}\], "resolution\_sources": \["deployments\.apps"\], "resolved\_versions": \["3\.2\.0"\], "raw\_detected\_versions": \["v3\.2\.0"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://argo-cd.readthedocs.io/en/release-3.2/operator-manual/tested-kubernetes-versions/>)

### VERSION\_EOL · WARN · MEDIUM

Versión fuera de mantenimiento según la evidencia oficial registrada\.

Categoría: operator\_compatibility · Relación: documented · Método: static

Evidencia: \{"product": "Istio", "installed\_version": "1\.24\.1", "target": "1\.35\.9", "matrix": \{"version": "1\.24\.x", "min\_kubernetes": "1\.28\.0", "max\_kubernetes": "1\.31\.x", "matrix\_type": "supported", "exclusive": true, "end\_of\_support": "2025\-06\-24", "source": "https://istio\.io/latest/docs/releases/supported\-releases/", "reviewed\_on": "2026\-11\-04", "valid\_until": "2027\-02\-02", "evidence": "Fila oficial 1\.24: soporte Kubernetes 1\.28–1\.31; EOL 24 junio 2025\.", "support\_state": "supported"\}, "detected\_version": "1\.24\.1", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["istio\.json"\], "paths": \["catalogs/support/istio\.json"\], "available\_selectors": \["1\.30\.x", "1\.29\.x", "1\.28\.x", "1\.27\.x", "1\.26\.x", "1\.25\.x", "1\.24\.x", "1\.23\.x", "1\.22\.x", "1\.21\.x"\], "matched\_selectors": \["1\.24\.x"\], "selected\_selector": "1\.24\.x", "normalized\_version": "1\.24\.1", "reason": "matched"\}, "distribution\_revision": null, "reviewed\_on": "2026\-11\-04", "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "deployments\.apps", "namespace": "system", "name": "istiod", "repository": "docker\.io/istio/pilot", "declared\_tag": "1\.24\.1", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "discovery", "container\_type": "containers", "image": "docker\.io/istio/pilot:1\.24\.1", "repository": "docker\.io/istio/pilot", "declared\_tag": "1\.24\.1", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}\], "resolution\_sources": \["deployments\.apps"\], "resolved\_versions": \["1\.24\.1"\], "raw\_detected\_versions": \["1\.24\.1"\], "detection\_summary": \{"scope": "Inventario examinado; sujeto a límites y errores de las fuentes\.", "control\_plane": \[\{"component": "istiod", "name": "istiod", "namespace": "system", "version": "1\.24\.1", "from": "deployments\.apps"\}\], "control\_plane\_pods\_by\_version": \{\}, "gateway\_pods\_by\_version": \{\}, "helm\_releases": \[\], "data\_plane": \{"pods\_observed": 0, "active\_pods": 0, "inactive\_pods": 0, "runtime\_confirmed\_active\_pods": 0, "inactive\_reasons": \{\}, "operational\_warnings": \{\}, "pending\_warning\_after\_seconds": 300, "other\_active\_versions": 0, "by\_version": \[\]\}, "inventory\_errors": \[\{"source": "pods", "reason": "inventory\_limit"\}\], "optional\_sources\_unavailable": \[\{"source": "istioctl version", "reason": "binary\_missing", "status": "OPTIONAL\_SOURCE\_UNAVAILABLE", "impact": "none\_for\_version\_detection"\}\]\}\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://istio.io/latest/docs/releases/supported-releases/>)

### NOT\_COMPATIBLE · FAIL · HIGH

El objetivo está fuera de la matriz oficial: bloqueo por política de soporte \(FAIL\_SUPPORT\_POLICY\), no una falla técnica demostrada\.

Categoría: operator\_compatibility · Relación: documented · Método: static

Evidencia: \{"product": "Istio", "installed\_version": "1\.24\.1", "target": "1\.35\.9", "matrix": \{"version": "1\.24\.x", "min\_kubernetes": "1\.28\.0", "max\_kubernetes": "1\.31\.x", "matrix\_type": "supported", "exclusive": true, "end\_of\_support": "2025\-06\-24", "source": "https://istio\.io/latest/docs/releases/supported\-releases/", "reviewed\_on": "2026\-11\-04", "valid\_until": "2027\-02\-02", "evidence": "Fila oficial 1\.24: soporte Kubernetes 1\.28–1\.31; EOL 24 junio 2025\.", "support\_state": "supported"\}, "detected\_version": "1\.24\.1", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["istio\.json"\], "paths": \["catalogs/support/istio\.json"\], "available\_selectors": \["1\.30\.x", "1\.29\.x", "1\.28\.x", "1\.27\.x", "1\.26\.x", "1\.25\.x", "1\.24\.x", "1\.23\.x", "1\.22\.x", "1\.21\.x"\], "matched\_selectors": \["1\.24\.x"\], "selected\_selector": "1\.24\.x", "normalized\_version": "1\.24\.1", "reason": "matched"\}, "distribution\_revision": null, "reviewed\_on": "2026\-11\-04", "catalog\_limitations": \[\], "failure\_domain": "SUPPORT\_POLICY", "support\_status": "FAIL\_SUPPORT\_POLICY", "technical\_status": "NOT\_TESTED", "detection\_sources": \[\{"from": "deployments\.apps", "namespace": "system", "name": "istiod", "repository": "docker\.io/istio/pilot", "declared\_tag": "1\.24\.1", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "discovery", "container\_type": "containers", "image": "docker\.io/istio/pilot:1\.24\.1", "repository": "docker\.io/istio/pilot", "declared\_tag": "1\.24\.1", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}\], "resolution\_sources": \["deployments\.apps"\], "resolved\_versions": \["1\.24\.1"\], "raw\_detected\_versions": \["1\.24\.1"\], "detection\_summary": \{"scope": "Inventario examinado; sujeto a límites y errores de las fuentes\.", "control\_plane": \[\{"component": "istiod", "name": "istiod", "namespace": "system", "version": "1\.24\.1", "from": "deployments\.apps"\}\], "control\_plane\_pods\_by\_version": \{\}, "gateway\_pods\_by\_version": \{\}, "helm\_releases": \[\], "data\_plane": \{"pods\_observed": 0, "active\_pods": 0, "inactive\_pods": 0, "runtime\_confirmed\_active\_pods": 0, "inactive\_reasons": \{\}, "operational\_warnings": \{\}, "pending\_warning\_after\_seconds": 300, "other\_active\_versions": 0, "by\_version": \[\]\}, "inventory\_errors": \[\{"source": "pods", "reason": "inventory\_limit"\}\], "optional\_sources\_unavailable": \[\{"source": "istioctl version", "reason": "binary\_missing", "status": "OPTIONAL\_SOURCE\_UNAVAILABLE", "impact": "none\_for\_version\_detection"\}\]\}\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://istio.io/latest/docs/releases/supported-releases/>)

### NO\_OFFICIAL\_NUMERIC\_MATRIX · UNKNOWN · INFO

Gatekeeper 3\.23\.1 fue detectado; la política oficial de releases no proporciona una matriz numérica revisada que acredite Kubernetes 1\.35\.9 para este binario\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Gatekeeper", "installed\_version": "v3\.23\.1\-8", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "v3\.23\.1\-8", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["gatekeeper\.json"\], "paths": \["catalogs/support/gatekeeper\.json"\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "3\.23\.1", "reason": "no\_numeric\_rows"\}, "distribution\_revision": "8", "reviewed\_on": null, "catalog\_limitations": \["La política general de versiones soportadas no prueba una matriz de cada binario antiguo\. Sin fila revisada se informa UNKNOWN\."\], "legacy\_rule\_id": "NO\_SUPPORT\_DATA", "raw\_version": "v3\.23\.1\-8", "upstream\_version": "3\.23\.1", "repository": "mcr\.microsoft\.com/oss/v2/open\-policy\-agent/gatekeeper", "normalization\_rule": "microsoft\_packaging\_revision", "detection\_sources": \[\{"from": "deployments\.apps", "namespace": "system", "name": "gatekeeper\-audit", "repository": "mcr\.microsoft\.com/oss/v2/open\-policy\-agent/gatekeeper", "declared\_tag": "v3\.23\.1\-8", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "manager", "container\_type": "containers", "image": "mcr\.microsoft\.com/oss/v2/open\-policy\-agent/gatekeeper:v3\.23\.1\-8", "repository": "mcr\.microsoft\.com/oss/v2/open\-policy\-agent/gatekeeper", "declared\_tag": "v3\.23\.1\-8", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag", "version\_normalization": \{"raw\_version": "v3\.23\.1\-8", "upstream\_version": "3\.23\.1", "distribution\_revision": "8", "repository": "mcr\.microsoft\.com/oss/v2/open\-policy\-agent/gatekeeper", "normalization\_rule": "microsoft\_packaging\_revision"\}\}\], "resolution\_sources": \["deployments\.apps"\], "resolved\_versions": \["3\.23\.1"\], "raw\_detected\_versions": \["v3\.23\.1\-8"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/open-policy-agent/gatekeeper/blob/master/docs/Release_Management.md>)

### COMPATIBLE · PASS · INFO

Objetivo dentro del rango documentado; consultar si la evidencia acredita soporte o pruebas upstream\.

Categoría: operator\_compatibility · Relación: documented · Método: static

Evidencia: \{"product": "Calico", "installed\_version": "3\.31\.2", "target": "1\.35\.9", "matrix": \{"version": "3\.31\.x", "supported\_kubernetes": \{"min": "1\.32", "max": "1\.35"\}, "matrix\_type": "tested", "exclusive": false, "support\_state": "supported", "source": "https://raw\.githubusercontent\.com/tigera/docs/master/calico\_versioned\_docs/version\-3\.31/\_includes/partials/\_system\-requirements\.mdx", "reviewed\_on": "2026\-11\-04", "evidence": "Requisitos de Calico 3\.31: versiones activamente probadas 1\.32, 1\.33, 1\.34 y 1\.35\. Otras pueden funcionar; no es un máximo de soporte estricto\.", "min\_kubernetes": "1\.32", "max\_kubernetes": "1\.35", "valid\_until": "2027\-02\-02"\}, "detected\_version": "3\.31\.2", "version\_confidence": "product\_metadata", "catalog\_lookup": \{"catalog\_present": true, "files": \["calico\.json"\], "paths": \["catalogs/support/calico\.json"\], "available\_selectors": \["3\.31\.x", "3\.32\.x"\], "matched\_selectors": \["3\.31\.x"\], "selected\_selector": "3\.31\.x", "normalized\_version": "3\.31\.2", "reason": "matched"\}, "distribution\_revision": null, "reviewed\_on": "2026\-11\-04", "catalog\_limitations": \["No se pudo verificar la documentación archivada 3\.30: permanece sin rango\. Tigera Operator tiene su propia versión, distinta de Calico\."\], "detection\_sources": \[\{"from": "Calico ClusterInformation", "activity": "active"\}\], "resolution\_sources": \["Calico ClusterInformation"\], "resolved\_versions": \["3\.31\.2"\], "raw\_detected\_versions": \["v3\.31\.2"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://raw.githubusercontent.com/tigera/docs/master/calico_versioned_docs/version-3.31/_includes/partials/_system-requirements.mdx>)

### NO\_SUPPORT\_DATA · UNKNOWN · INFO

No existe una única fila de matriz oficial revisada para esta versión\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Tigera Operator", "installed\_version": "v1\.40\.15\-4", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "v1\.40\.15\-4", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["tigera\-operator\.json"\], "paths": \["catalogs/support/tigera\-operator\.json"\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "1\.40\.15", "reason": "no\_numeric\_rows"\}, "distribution\_revision": "4", "reviewed\_on": null, "catalog\_limitations": \["La versión del operador no es la de Calico\. Un manifiesto que relaciona ambos artefactos no demuestra por sí mismo la matriz Kubernetes del operador; no se copia soporte entre productos\."\], "raw\_version": "v1\.40\.15\-4", "upstream\_version": "1\.40\.15", "repository": "mcr\.microsoft\.com/oss/v2/tigera/operator", "normalization\_rule": "microsoft\_packaging\_revision", "detection\_sources": \[\{"from": "deployments\.apps", "namespace": "system", "name": "tigera\-operator", "repository": "mcr\.microsoft\.com/oss/v2/tigera/operator", "declared\_tag": "v1\.40\.15\-4", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "tigera\-operator", "container\_type": "containers", "image": "mcr\.microsoft\.com/oss/v2/tigera/operator:v1\.40\.15\-4", "repository": "mcr\.microsoft\.com/oss/v2/tigera/operator", "declared\_tag": "v1\.40\.15\-4", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag", "version\_normalization": \{"raw\_version": "v1\.40\.15\-4", "upstream\_version": "1\.40\.15", "distribution\_revision": "4", "repository": "mcr\.microsoft\.com/oss/v2/tigera/operator", "normalization\_rule": "microsoft\_packaging\_revision"\}\}\], "resolution\_sources": \["deployments\.apps"\], "resolved\_versions": \["1\.40\.15"\], "raw\_detected\_versions": \["v1\.40\.15\-4"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/tigera/operator>)

### NO\_OFFICIAL\_KUBERNETES\_MATRIX · UNKNOWN · INFO

La versión 1\.1\.2 fue detectada, pero no se encontró en las fuentes oficiales revisadas una matriz numérica verificable que la vincule con Kubernetes 1\.35\.9\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Secrets Store CSI Driver", "installed\_version": "1\.1\.2", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "1\.1\.2", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["secrets\-store\-csi\.json"\], "paths": \["catalogs/support/secrets\-store\-csi\.json"\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "1\.1\.2", "reason": "no\_numeric\_rows"\}, "distribution\_revision": null, "reviewed\_on": null, "catalog\_limitations": \["La política soporta Kubernetes minor activamente soportados\. No fija una matriz para cualquier binario histórico: no se extrapola la política actual a versiones instaladas antiguas\."\], "legacy\_rule\_id": "NO\_SUPPORT\_DATA", "detection\_sources": \[\{"from": "daemonsets\.apps", "namespace": "system", "name": "secrets\-store\-csi", "repository": "registry\.k8s\.io/csi\-secrets\-store/driver", "declared\_tag": "v1\.1\.2", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "manager", "container\_type": "containers", "image": "registry\.k8s\.io/csi\-secrets\-store/driver:v1\.1\.2", "repository": "registry\.k8s\.io/csi\-secrets\-store/driver", "declared\_tag": "v1\.1\.2", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}\], "resolution\_sources": \["daemonsets\.apps"\], "resolved\_versions": \["1\.1\.2"\], "raw\_detected\_versions": \["v1\.1\.2"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://secrets-store-csi-driver.sigs.k8s.io/getting-started/installation>)

### NO\_SUPPORT\_DATA · UNKNOWN · INFO

No existe una única fila de matriz oficial revisada para esta versión\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Azure Key Vault Provider for Secrets Store CSI Driver", "installed\_version": "1\.1\.0", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "1\.1\.0", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": false, "files": \[\], "paths": \[\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "1\.1\.0", "reason": "catalog\_missing"\}, "distribution\_revision": null, "reviewed\_on": null, "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "daemonsets\.apps", "namespace": "system", "name": "provider", "repository": "mcr\.microsoft\.com/oss/azure/secrets\-store/provider\-azure", "declared\_tag": "v1\.1\.0", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "manager", "container\_type": "containers", "image": "mcr\.microsoft\.com/oss/azure/secrets\-store/provider\-azure:v1\.1\.0", "repository": "mcr\.microsoft\.com/oss/azure/secrets\-store/provider\-azure", "declared\_tag": "v1\.1\.0", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}, \{"from": "az aks show", "addon": "azureKeyvaultSecretsProvider", "activity": "active"\}\], "resolution\_sources": \["daemonsets\.apps"\], "resolved\_versions": \["1\.1\.0"\], "raw\_detected\_versions": \["v1\.1\.0"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://learn.microsoft.com/en-us/azure/aks/csi-secrets-store-driver>)

### NO\_SUPPORT\_DATA · UNKNOWN · INFO

No existe una única fila de matriz oficial revisada para esta versión\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Azure Disk CSI Driver", "installed\_version": "v1\.34\.7\-7", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "v1\.34\.7\-7", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["azure\-disk\.json"\], "paths": \["catalogs/support/azure\-disk\.json"\], "available\_selectors": \["1\.34\.5", "1\.33\.11", "1\.36\.0"\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "1\.34\.7", "reason": "family\_not\_catalogued"\}, "distribution\_revision": "7", "reviewed\_on": null, "catalog\_limitations": \["No se extrapolan filas exactas a toda la familia 1\.34\.x\. Los tags con revisión de distribución se conservan; su soporte requiere vendor\_versions documentadas\."\], "detection\_sources": \[\{"from": "daemonsets\.apps", "namespace": "system", "name": "disk", "repository": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azuredisk\-csi", "declared\_tag": "v1\.34\.7\-7", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "manager", "container\_type": "containers", "image": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azuredisk\-csi:v1\.34\.7\-7", "repository": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azuredisk\-csi", "declared\_tag": "v1\.34\.7\-7", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}, \{"from": "az aks show", "addon": "diskCSIDriver", "activity": "active"\}\], "resolution\_sources": \["daemonsets\.apps"\], "resolved\_versions": \["v1\.34\.7\-7"\], "raw\_detected\_versions": \["v1\.34\.7\-7"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/kubernetes-sigs/azuredisk-csi-driver>)

### NO\_SUPPORT\_DATA · UNKNOWN · INFO

No existe una única fila de matriz oficial revisada para esta versión\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Azure File CSI Driver", "installed\_version": "v1\.35\.11\-6", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "v1\.35\.11\-6", "version\_confidence": "image\_tag", "catalog\_lookup": \{"catalog\_present": true, "files": \["azure\-file\.json"\], "paths": \["catalogs/support/azure\-file\.json"\], "available\_selectors": \["1\.35\.7", "1\.34\.8", "1\.33\.10"\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": "1\.35\.11", "reason": "family\_not\_catalogued"\}, "distribution\_revision": "6", "reviewed\_on": null, "catalog\_limitations": \["No se encontró una matriz para v1\.35\.11\-6\. No se sustituye su versión detectada por UNKNOWN ni se extiende el soporte de 1\.35\.7 por similitud de minor\."\], "detection\_sources": \[\{"from": "daemonsets\.apps", "namespace": "system", "name": "file", "repository": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azurefile\-csi", "declared\_tag": "v1\.35\.11\-6", "revision": null, "identity\_basis": "catalog\_repository", "confidence": "image\_tag", "activity": "active", "observed\_status": \{"availableReplicas": 1, "conditions": \[\]\}, "version\_label": null, "chart": null, "imageID": null, "observed\_containers": \[\{"container": "manager", "container\_type": "containers", "image": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azurefile\-csi:v1\.35\.11\-6", "repository": "mcr\.microsoft\.com/oss/v2/kubernetes\-csi/azurefile\-csi", "declared\_tag": "v1\.35\.11\-6", "imageID": null, "ready": null, "restartCount": null, "state": \{\}\}\], "pod\_container\_statuses": \[\], "version\_basis": "workload\_template\_image\_tag"\}, \{"from": "az aks show", "addon": "fileCSIDriver", "activity": "active"\}\], "resolution\_sources": \["daemonsets\.apps"\], "resolved\_versions": \["v1\.35\.11\-6"\], "raw\_detected\_versions": \["v1\.35\.11\-6"\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/kubernetes-sigs/azurefile-csi-driver>)

### VERSION\_UNKNOWN · UNKNOWN · INFO

No se determinó una versión de producto inequívoca; un chart, digest o tag mutable no demuestra versión efectiva\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Azure Policy Add\-on", "installed\_version": "UNKNOWN", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "UNKNOWN", "version\_confidence": "product\_metadata", "catalog\_lookup": \{"catalog\_present": false, "files": \[\], "paths": \[\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": null, "reason": "version\_missing"\}, "distribution\_revision": null, "reviewed\_on": null, "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "az aks show", "addon": "azurepolicy", "activity": "active", "note": "Habilitado no determina versión efectiva\."\}\], "resolution\_sources": \["az aks show"\], "resolved\_versions": \[\], "raw\_detected\_versions": \[\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://learn.microsoft.com/en-us/azure/governance/policy/concepts/policy-for-kubernetes>)

### VERSION\_UNKNOWN · UNKNOWN · INFO

No se determinó una versión de producto inequívoca; un chart, digest o tag mutable no demuestra versión efectiva\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Defender for Cloud", "installed\_version": "UNKNOWN", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "UNKNOWN", "version\_confidence": "product\_metadata", "catalog\_lookup": \{"catalog\_present": false, "files": \[\], "paths": \[\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": null, "reason": "version\_missing"\}, "distribution\_revision": null, "reviewed\_on": null, "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "az aks show", "addon": "Defender for Containers", "activity": "active", "note": "Habilitado no determina versión efectiva\."\}\], "resolution\_sources": \["az aks show"\], "resolved\_versions": \[\], "raw\_detected\_versions": \[\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-containers-introduction>)

### MANAGED\_VERSION\_NOT\_EXPOSED · UNKNOWN · INFO

Snapshot Controller habilitado en metadata AKS; la versión efectiva y su soporte para el objetivo no están expuestos\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Snapshot Controller", "target": "1\.35\.9", "installed\_version": "MANAGED", "detected\_version": "MANAGED", "managed\_by": "AKS", "reason": "MANAGED\_VERSION\_NOT\_EXPOSED", "legacy\_rule\_id": "MANAGED\_VERSION\_UNEXPOSED", "detection\_sources": \[\{"from": "az aks show", "addon": "snapshotController", "activity": "active", "note": "Habilitado no determina versión efectiva\."\}\], "resolution\_sources": \["az aks show"\], "resolved\_versions": \[\], "version\_confidence": "managed\_metadata", "raw\_detected\_versions": \["MANAGED"\]\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/kubernetes-csi/external-snapshotter>)

### VERSION\_UNKNOWN · UNKNOWN · INFO

No se determinó una versión de producto inequívoca; un chart, digest o tag mutable no demuestra versión efectiva\.

Categoría: operator\_compatibility · Relación: limitation · Método: static

Evidencia: \{"product": "Cluster Autoscaler", "installed\_version": "UNKNOWN", "target": "1\.35\.9", "matrix": \{\}, "detected\_version": "UNKNOWN", "version\_confidence": "product\_metadata", "catalog\_lookup": \{"catalog\_present": false, "files": \[\], "paths": \[\], "available\_selectors": \[\], "matched\_selectors": \[\], "selected\_selector": null, "normalized\_version": null, "reason": "version\_missing"\}, "distribution\_revision": null, "reviewed\_on": null, "catalog\_limitations": \[\], "detection\_sources": \[\{"from": "az aks show", "addon": "Cluster Autoscaler", "activity": "active", "note": "Habilitado no determina versión efectiva\."\}\], "resolution\_sources": \["az aks show"\], "resolved\_versions": \[\], "raw\_detected\_versions": \[\]\}

Recomendación: Revisar la matriz oficial y actualizar el componente o completar evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler>)

### PLATFORM\-DISCOVERY · UNKNOWN · INFO

Cobertura del descubrimiento de plataformas\.

Categoría: operator\_compatibility · Relación: limitation · Método: snapshot

Evidencia: \{"errors": \[\{"source": "pods", "reason": "inventory\_limit"\}\], "required\_errors": \[\{"source": "pods", "completed": false, "authorized": null, "error": "inventory\_limit", "items\_scanned": 120, "required": true, "inventory\_complete": false, "pages": 6, "continuation\_pending": false, "safety\_limit": 20000, "page\_size": 500\}\], "detector\_errors": \[\], "inventory\_sources": \[\{"source": "deployments\.apps", "completed": true, "authorized": true, "error": null, "items\_scanned": 4, "required": true\}, \{"source": "daemonsets\.apps", "completed": true, "authorized": true, "error": null, "items\_scanned": 4, "required": true\}, \{"source": "statefulsets\.apps", "completed": true, "authorized": true, "error": null, "items\_scanned": 0, "required": true\}, \{"source": "pods", "completed": false, "authorized": null, "error": "inventory\_limit", "items\_scanned": 120, "required": true, "inventory\_complete": false, "pages": 6, "continuation\_pending": false, "safety\_limit": 20000, "page\_size": 500\}, \{"source": "nodes", "completed": true, "authorized": true, "error": null, "items\_scanned": 0, "required": true\}, \{"source": "Helm", "completed": true, "authorized": true, "error": null, "items\_scanned": 0, "required": false\}, \{"source": "istioctl version", "completed": false, "authorized": null, "error": null, "items\_scanned": 0, "required": false, "status": "OPTIONAL\_SOURCE\_UNAVAILABLE", "reason": "binary\_missing", "impact": "none\_for\_version\_detection"\}, \{"source": "crds", "completed": true, "authorized": true, "error": null, "items\_scanned": 1, "required": true\}\], "products\_detected": 13\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

- Límite: Detectores por repositorios y charts conocidos\. Mirrors privados, productos no catalogados y planos administrados pueden no ser visibles\.
- Límite: La versión de tag/Helm es evidencia declarada, no una verificación del binario por digest\.
- Límite: Las listas de workloads se descargan completas dentro del timeout y se examinan hasta el límite configurado\.
### AKS\-SUPPORT\-UNVERIFIED · UNKNOWN · INFO

Soporte de AKS y sus add\-ons para el objetivo requiere evidencia específica de Microsoft\.

Categoría: aks · Relación: limitation · Método: static

Evidencia: \{"detected": true, "target\_version": "1\.35\.9", "current\_version": "1\.34\.8", "node\_image\_versions": \[\], "node\_kubelet\_versions": \[\], "addons": \[\{"name": "azurepolicy", "detector\_id": "azure\-policy"\}, \{"name": "azureKeyvaultSecretsProvider", "detector\_id": "azure\-keyvault"\}, \{"name": "Defender for Containers", "detector\_id": "defender"\}, \{"name": "snapshotController", "detector\_id": "snapshot"\}, \{"name": "diskCSIDriver", "detector\_id": "azure\-disk"\}, \{"name": "fileCSIDriver", "detector\_id": "azure\-file"\}, \{"name": "Cluster Autoscaler", "detector\_id": "autoscaler"\}\], "limitations": \["Metadata AKS observada; la versión efectiva y soporte de cada add\-on se evalúan por separado\.", "Una versión Kubernetes soportada upstream no acredita disponibilidad de upgrade, región, canal LTS ni soporte del add\-on administrado en AKS\.", "Node images se inventarían; no se infiere compatibilidad futura por su nombre\."\], "resource\_id": "/subscriptions/synthetic/resourceGroups/demo/providers/Microsoft\.ContainerService/managedClusters/partial", "subscription\_id": null, "resource\_group": null, "cluster\_name": null, "network\_profile": \{"networkPlugin": null, "networkPluginMode": null, "networkDataplane": null, "networkPolicy": null\}\}

Recomendación: Revisar versiones/región/canal AKS, imágenes de nodos y versiones administradas de add\-ons antes del upgrade\.

Fuente: [Referencia técnica](<https://learn.microsoft.com/en-us/azure/aks/supported-kubernetes-versions>)

### PLUTO\-SCAN · UNKNOWN · INFO

Pluto no se ejecuta en modo offline\.

Categoría: native\_api\_deprecations · Relación: limitation · Método: external\_tool

Evidencia: \{"exit\_code": null, "executed": false\}

Recomendación: Revisar la sección Pluto y mantener actualizado el binario y su catálogo de APIs\.

Fuente: [Referencia técnica](<https://pluto.docs.fairwinds.com/advanced/>)

- Límite: Pluto tiene su propio catálogo de APIs; un resultado limpio no prueba cobertura de versiones futuras\.
- Límite: La detección depende de los objetos y metadatos disponibles para Pluto\.

## widgets\.example\.com — UNKNOWN / INFO

### STRUCTURE\-BASIC · PASS · INFO

Identidad, scope, nombres y versiones con estructura válida\.

Categoría: structure · Relación: preexisting · Método: static

Evidencia: \{\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

### STORAGE\-CONSISTENT · PASS · INFO

Declaraciones served, storage y storedVersions coherentes\.

Categoría: storage · Relación: preexisting · Método: static

Evidencia: \{"served": \["v1alpha1"\], "storage": \["v1alpha1"\], "stored\_versions": \["v1alpha1"\]\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definition-versioning/>)

### SCHEMA\-STATIC · PASS · INFO

No se detectaron errores en el subconjunto estático del esquema\.

Categoría: schema · Relación: preexisting · Método: static

Evidencia: \{"path": "spec\.versions\[v1alpha1\]\.schema\.openAPIV3Schema"\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

- Límite: No valida completamente defaults, regex RE2, formatos, CEL, admisión o datos persistidos\.
### CONVERSION\-NONE · PASS · INFO

Conversión None: no hay dependencia de un webhook\.

Categoría: conversion\_webhook · Relación: preexisting · Método: static

Evidencia: \{\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definition-versioning/>)

### NO\_PRODUCT\_OWNER · UNKNOWN · INFO

No existe una asociación explícita entre este CRD y un producto detectado\.

Categoría: operator · Relación: limitation · Método: static

Evidencia: \{\}

Recomendación: Registrar ownership documentado y detectar la versión del producto; no inferirla por labels o por la existencia del CRD\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

### K135\-CONDITION\-GENERATION · PASS · INFO

1\.35 incorpora observedGeneration en condiciones de CRDs\.

Categoría: structure · Relación: release\_change · Método: static

Evidencia: \{"basis": "Cambio aditivo documentado en las notas 1\.35, PR 134984\.", "applicability": \{"crosses": "1\.35\.0"\}, "condition\_matched": true\}

Recomendación: Revisar deserializadores estrictos en clientes propios que consuman condiciones de CRDs\.

Fuente: [Referencia técnica](<https://github.com/kubernetes/kubernetes/blob/master/CHANGELOG/CHANGELOG-1.35.md>)

- Límite: No se inspecciona el código del operador; este cambio no es un bloqueo por sí mismo\.
### INSTANCES\-NOT\-REQUESTED · UNKNOWN · INFO

Instancias no inspeccionadas; usar \-\-include\-instances para lectura limitada\.

Categoría: instances · Relación: limitation · Método: static

Evidencia: \{\}

Recomendación: Revisar la evidencia antes del upgrade\.

Fuente: [Referencia técnica](<https://v1-35.docs.kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definitions/>)

